import { MeetingsService } from './../../services/meetings.service';
import { Component, OnInit } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { meetings } from 'src/app/services/details';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

///public variable
  public bookings = [] ;
  public date: any;
  public allbookings:any[];
  public data:any;
  totmin : any;
  min: any = new Date().getMinutes();
  hr: any = new Date().getHours();

  constructor(private info: MeetingsService,public toastr: ToastrManager,private modalService: NgbModal) { }


  hideBooking(id){
    this.info.hideBooking(id);
    console.log(this.info.hideBooking(id));
  }

  openXl(content,id) {
    console.log(id);
    this.info.getSingleBooking(id).get().forEach(i => {
      if(i.data()){
        console.log('document : ', i.data().id);
        this.data = i.data();
      }else {
        console.log('No such file');
      }
    }).catch ( e => {
      this.toastr.errorToastr('Something went wrong, try again.', 'Oops!');
    })
    this.modalService.open(content, { size: 'xl' });
  }


  ngOnInit() {
    this.totmin = this.info.updateTime();
    console.log('get total minutes times : ' + this.totmin);
    this.date = this.info.ShortDate();
    this.info.getTodays(this.date,this.totmin).snapshotChanges()
    .subscribe(i => {
      this.bookings = i;
      console.log(this.bookings);
    })

   
    //all meetings
    this.info.getWeekMeetings().snapshotChanges()
    .subscribe( i => {
      this.allbookings = i;
    })

    //time
    this.totmin = this.min + (this.hr * 60);
    console.log(this.min , ' : ', this.hr , ' total min : ', this.totmin);
  }

}
