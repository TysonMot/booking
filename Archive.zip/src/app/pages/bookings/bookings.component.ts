import { MeetingsService } from './../../services/meetings.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AngularFirestore } from '@angular/fire/firestore';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { meetings } from 'src/app/services/details';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css']
})
export class BookingsComponent implements OnInit {

  constructor(private data: MeetingsService,
     private _fire: AngularFirestore,
     public toastr: ToastrManager,
     private modalService: NgbModal) { }

    //auto assign value
    public value = '';


     date:any;
     starttime = new Array();
     start:any[] = [];
     endtime = [];
     e :number = 550;
      startMinutes: number;
      EndMinutes: number;
      minutes: number;
      hours: number;
      Eminutes: number;
      Ehours: number;
      d:number = 0;

    //testing
    time : any = [];
    End:any = [];
    Start: any = [];
    Max = 1080; //end of the day
    Min = 420; //start
    k: number =0;
    counttime = [];
    ///status
    status: boolean = false;
    status2: boolean = false;
    status3: boolean = false;
    status4: boolean = false;
    status5: boolean = false;
    max : any;


    // if(StartA < StartB && EndA < StartB){
    //   console.log('available');
    // }elseif (StartA > EndB) {
    //   console.log('available')
    // }else {
    //   console.log('No slots available for today');
    // }



  ngOnInit() {
    this.date = this.data.ShortDate();
    this.date = this.data.ShortDate();
    //console.log(this.Boardroom);
    //this.gettodaysmeetings();
    this.data.testing(this.date).valueChanges().subscribe(i => {
      console.log(i);
      i.map(e => {
        console.log(e.End);
      })
      if(i){
        for(var e = 0; e < i.length; e++){
          console.log(i[e].End)
        }
      }
    })
  }

  // gettodaysmeetings() {
  //   this.data.getboardroommeetings(this.data.ShortDate(),this.Boardroom).get().forEach( i => {
  //     console.log(i);
  //   })
  // }

  book(f: NgForm){
    
    //validation
    if(f.valid === false){
        this.toastr.warningToastr('Oops! kindly fill out all the inputs.', 'Error');
    }else{
  
    let id = this._fire.createId();
      //get minutes and hours
      this.minutes = f.value.Starttime.slice(0,2);
      this.minutes = this.minutes * 60;
      this.Eminutes = f.value.Endtime.slice(0,2);
      this.Eminutes = this.Eminutes * 60;
      //hours
      this.hours = f.value.Starttime.slice(3,5);
      this.hours = this.hours * 1;
      this.Ehours = f.value.Endtime.slice(3,5);
      this.Ehours = this.Ehours * 1;
      //console.log('dsdsd: ' + this.hours)
      //total minutes
      this.startMinutes = this.minutes + this.hours;
      this.EndMinutes = this.Eminutes + this.Ehours;
     //check times

     console.log(this.startMinutes,this.EndMinutes);
      console.log(f.value.boardroom);
      
     ///
      if(this.EndMinutes < this.startMinutes) {
        this.toastr.warningToastr('Oops! End time cannot be less than start time.', 'Error!');
      }else  {
        ///
        const booking = {
          //boardroom booking details
          id : id,
          boardroom: f.value.boardroom,
          Reason: f.value.reason,
          Startdate: f.value.StartDate,
          EndDate: f.value.EndDate,
          start:this.startMinutes,
          End:  this.EndMinutes,
          Starttime: f.value.Starttime,
          Endtime: f.value.Endtime,
          dsc: f.value.dsc,
          //personal or company details
          Comp_Name: f.value.compname,
          Name: f.value.name,
          Surname: f.value.surname,
          Contacts: f.value.contacts,
          hide: 'true'
        }
//conditions to check if slots are available
this.data.gettime(f.value.StartDate,f.value.boardroom).valueChanges().subscribe(i => {
  if(i){
    for(var k =0; k < i.length;k++){
      //console.log(i[k].payload.doc.data().start,i[k].payload.doc.data().End);
      this.Start.push(i[k].start);
      this.End.push(i[k].End)
      this.max = Math.max(this.End);
      
    }
console.log('here is a max value :' + this.max);

//status one to find if all start values are greater than start time of provided meeting time
this.status = this.Start.every(i => i >= this.startMinutes);
//status two to find if all start values are greater than end time of provided meeting time
this.status2 = this.Start.every(i => i >= this.EndMinutes);
//status three to find if all end values are greater than start time of provided meeting time
this.status3 = this.End.every(i => i <= this.startMinutes);
// console.log(this.status3);
//start available is greater than equals provided end time
this.status4 = this.End.some(i => i >= this.EndMinutes);
//end value provided is less than equals to start time of available meeting.
//this.status5 = this.End.some(i => i >= this.startMinutes);
console.log('stauts : ' + this.status4,this.status5);

///if statement to check if all statuses are true
if(this.status === true && this.status2 === true){
this.toastr.infoToastr('Available, meeting slots is available for ' + f.value.boardroom + ', register booking', 'Info');
this.Start = [];
this.End = [];
////

this.data.firebase(booking);

///
} else if(this.status3 === true) {
this.toastr.infoToastr('Available, meeting slots is available for  ' + f.value.boardroom + ', register booking', 'Info');
this.Start = [];
this.End = [];
//
this.data.firebase(booking);
//
} else {
this.toastr.infoToastr('Available, meeting slots for the supplied times are already taken, please check the schedule', 'Info');
this.Start = [];
this.End = [];
}
}
})
      }

    }
    }
    openScrollableContent(longContent) {
      this.modalService.open(longContent, { scrollable: true });
    }

}
