import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MeetingsComponent } from './pages/meetings/meetings.component';
import { BookingsComponent } from './pages/bookings/bookings.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field';
import { Details } from './services/details';
import { FormsModule } from '@angular/forms';
import { AngularFireModule } from '@angular/fire';
import { environment } from '../environments/environment';
import { AngularFirestoreModule } from '@angular/fire/firestore';
//import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ToastrModule } from 'ng6-toastr-notifications';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    MeetingsComponent,
    BookingsComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFontAwesomeModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    FormsModule,
    NgbModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFirestoreModule,
    ToastrModule.forRoot()
  ],
  providers: [
    MeetingsComponent,
    Details
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
