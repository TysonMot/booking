export class Details {
  //empty array
  bookings: any[] = [];
}

export interface meetings {
    //boardroom booking details
    id:String;
    boardroom: String;
    Reason: String;
    Startdate: Date;
    EndDate: Date;
    start: any;
    End: any;
    dsc: String;
    //personal or company details
    Comp_Name:String;
    Name: String;
    Surname: String;
    Contacts: number;

}