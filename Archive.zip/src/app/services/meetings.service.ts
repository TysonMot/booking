import { Injectable } from '@angular/core';
import { Details, meetings } from './details';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import 'firebase/firestore';
import { reject } from 'q';
import { Observable } from 'rxjs';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class MeetingsService {

meetingsRef: AngularFirestoreCollection<meetings>;
meetings$ : Observable<meetings[]>;
getID: meetings[];
time : any = new Date().getTime();

totmin : any;

  constructor(private details: Details,
     private fire:AngularFirestore,
    public toastr: ToastrManager,
     private _redirect: Router) { }

updateTime(){
 
  let min = new Date().getMinutes();
  let hr = new Date().getHours();
  this.totmin = min + (hr * 60);

  //setInterval( this.updateTime(), 1000);

  return this.totmin;
}



  firebase(data){
    const id = this.fire.createId();
    this.fire.firestore.collection("bookings").add(data).
    then( res => {
      this.toastr.successToastr('Successfully booked a boardroom.', 'Success!');
      this._redirect.navigate(['/','dashboard']);
      
    }, err => reject(err));
  }

  getCollections(){
   return this.meetingsRef = this.fire.collection('bookings');
  }
  
  getMeetings(){
  return this.meetings$ = this.getCollections().valueChanges();
  }

  getTodays(date,time){
    console.log('todays date : ' + date);
    return this.meetingsRef = 
    this.fire.collection('bookings', ref => ref.where('Startdate','==', date).where('hide','==', 'true').
    where('End','>=', time));
  }
 
  getWeekMeetings(){
    return this.meetingsRef = 
    this.fire.collection('bookings', ref => ref.where('hide','==', 'true'));
  }
  // delete and update functions here

  // delete hides booking from meetings
  hideBooking(id){
    return this.fire.doc('bookings/' + id).update({
      'hide' : 'False'
    }).then ( e => {
      this.toastr.successToastr('Booking deleted', 'Success!');
    }).catch ( err => {
        this.toastr.errorToastr('Something went wrong', 'Oops!');
    });
  }

  getSingleBooking(id){
    return this.fire.collection('bookings').doc(id);
  }

  //check if time is available
  gettime(date,boardroom){
    return this.fire.collection('bookings', ref => ref.where('hide','==', 'true').where('Startdate','==',date).
    where('boardroom','==', boardroom));
  }

  //get meetings by boardroom value on booking page
  getboardroommeetings(date,value){
    return this.fire.collection('bookings', ref => ref.where('hide','==', 'true').where('Startdate','==',date).
    where('boardroom','==', value));
  }
  ///testing value changes
  testing(date){
    return this.fire.collection('bookings', ref => ref.where('hide','==', 'true'));
  }


  ShortDate(){
   let d: any = new Date();
   let month: any = d.getMonth() + 1;
   let year: any = d.getFullYear();
   let day: any = d.getDate();
   var newmonth:any;
   var newday: any;

    if(month > 9){
      newmonth = month;
    }else {
      newmonth = '0' + month;
    }

    if(day < 9){
      newday = '0' + day;
    }else {
      newday = day;
    }

   let date: any = year + '-' + newmonth + '-' + newday;  
   //setTimeout( this.ShortDate(), 1000);
   return date;
  }

  
}
