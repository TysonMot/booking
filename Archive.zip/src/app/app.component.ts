import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'booking';
  date: any = new Date();
  months: any [] = ["Jan","Feb","Mar","Apr","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  Year: any;
  Month: any;
  Date: any;
  StringMonth:any;
  time: any;

  ngOnInit() {
    this.Year = this.date.getFullYear();
    this.Month = this.date.getMonth();
    this.Date = this.date.getDate();
    this.StringMonth = this.months[this.Month];
    this.time = this.date.getHours() +':'+ this.date.getMinutes();
  }
}
